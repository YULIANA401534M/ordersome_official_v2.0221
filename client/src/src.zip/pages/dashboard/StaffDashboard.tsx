import { Link } from "wouter";
import StaffDashboardLayout from "@/components/StaffDashboardLayout";
import { Wrench, ClipboardList, BookOpen, Calendar, Bell } from "lucide-react";

export default function StaffDashboard() {
  return (
    <StaffDashboardLayout>
      <div className="py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-2xl p-8 mb-8 shadow-xl">
            <h1 className="text-3xl font-bold mb-2">歡迎回到員工專區</h1>
            <p className="text-purple-100">查看工作表單、提交維修申請、查看排班資訊</p>
          </div>

          {/* Quick Access Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Link
              to="/dashboard/sop"
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all border-2 border-transparent hover:border-purple-500 block"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-purple-100 rounded-lg">
                  <BookOpen className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900">SOP 知識庫</h3>
              </div>
              <p className="text-sm text-gray-600">查閱標準作業流程、訓練手冊與操作指引</p>
            </Link>
            <Link
              to="/dashboard/repairs"
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all border-2 border-transparent hover:border-purple-500 block"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-orange-100 rounded-lg">
                  <Wrench className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900">設備報修</h3>
              </div>
              <p className="text-sm text-gray-600">提交設備維修申請、查看維修進度</p>
            </Link>
            <Link
              to="/dashboard/checklist"
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all border-2 border-transparent hover:border-purple-500 block"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <ClipboardList className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900">每日檢查表</h3>
              </div>
              <p className="text-sm text-gray-600">填寫開店/閉店檢查表、查看歷史記錄</p>
            </Link>
          </div>
          {/* Secondary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div
              className="bg-white rounded-xl p-6 shadow-md border-2 border-transparent opacity-50 cursor-not-allowed pointer-events-none"
              title="尚未開放"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-gray-100 rounded-lg">
                  <Calendar className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-bold text-gray-500">排班系統</h3>
              </div>
              <p className="text-sm text-gray-400">查看本週排班、申請調班、請假</p>
              <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full mt-2 inline-block">即將推出</span>
            </div>
            <div
              className="bg-white rounded-xl p-6 shadow-md border-2 border-transparent opacity-50 cursor-not-allowed pointer-events-none"
              title="尚未開放"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-gray-100 rounded-lg">
                  <Bell className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-bold text-gray-500">公告事項</h3>
              </div>
              <p className="text-sm text-gray-400">查看最新公告、重要通知、活動資訊</p>
              <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full mt-2 inline-block">即將推出</span>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="mt-8 bg-white rounded-xl p-6 shadow-md">
            <h2 className="text-xl font-bold text-gray-900 mb-4">最新公告</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Bell className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">本週排班已公告</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    請至排班系統查看本週的工作班表
                  </p>
                  <p className="text-xs text-gray-400 mt-2">2026-01-19</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <ClipboardList className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">請記得填寫每日工作表單</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    每日下班前請至工作表單區填寫當日工作內容
                  </p>
                  <p className="text-xs text-gray-400 mt-2">2026-01-15</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Wrench className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">設備維修進度更新</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    您提交的冰箱維修申請已完成，請確認設備狀況
                  </p>
                  <p className="text-xs text-gray-400 mt-2">2026-01-18</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </StaffDashboardLayout>
  );
}
